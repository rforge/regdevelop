.onLoad <- function(lib, pkg) require(methods)

##- .onAttach <- function(libname, pkgname){
##-   cat("----------------------------------------------------------------------",
##-       "Please note that this is an early test release of package 'grplasso'.",
##-       "It should only be used for experimental reasons. Use at your own risk!",
##-       "----------------------------------------------------------------------",
##-       sep = "\n")
##- }
